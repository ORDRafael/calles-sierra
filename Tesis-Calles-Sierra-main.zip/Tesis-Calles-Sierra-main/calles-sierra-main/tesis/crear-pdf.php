<?php 
include('conexion.php');
include('TCPDF-main\tcpdf.php');

// Obtener el ID del paciente desde la URL
$idPaciente = $_GET['id'];


// Obtener los datos del informe del paciente desde la base de datos
$query = "SELECT * FROM informes WHERE id_paciente = $idPaciente";
$resultado = mysqli_query($conexion, $query);
$informe = mysqli_fetch_assoc($resultado);

$pdf = new TCPDF();

$pdf->SetCreator('Tu nombre');
$pdf->SetAuthor('Tu nombre');
$pdf->SetTitle('Informe del paciente');
$pdf->SetHeaderData('', 0, '', '', array(0,0,0), array(255,255,255));
$pdf->setHeaderFont(Array('helvetica', 'B', 12));
$pdf->setFooterFont(Array('helvetica', 'N', 12));
$pdf->SetDefaultMonospacedFont('courier');
$pdf->SetMargins(15, 15, 15);
$pdf->SetAutoPageBreak(TRUE, 15);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
$pdf->SetFont('helvetica', '', 12);
$pdf->AddPage();

$pdf->Cell(0, 10, 'Informe del paciente', 0, 1, 'C');
$pdf->Ln(10);

$pdf->Cell(0, 10, 'Fecha: ' . $informe['fecha'], 0, 1);
$pdf->Cell(0, 10, 'Diagnóstico: ' . $informe['diagnostico'], 0, 1);
$pdf->Cell(0, 10, 'Medicamentos: ' . $informe['medicamentos'], 0, 1);
$pdf->Cell(0, 10, 'Evolución: ' . $informe['evolucion'], 0, 1);
$pdf->Cell(0, 10, 'Recomendaciones: ' . $informe['recomendaciones'], 0, 1);
$pdf->Ln(10);

$pdf->MultiCell(0, 10, 'Contenido del informe:', 0, 'L');
$pdf->MultiCell(0, 10, $informe['contenido'], 0, 'L');

$pdf->Output('informe.pdf');