<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="menu-lateral">
  <ul>
    <li><a href="principal.php">Inicio</a></li>
    <li><a href="lista-paciente.php">Lista de Pacientes</a></li>
    <li><a href="registro-paciente.php">Registro de Pacientes</a></li>
    <li><a href="registro_medico.php">Registrar medicos</a></li>
    <li><a href="lista-medicos.php">Lista de Medicos</a></li>
    <li><a href="citas.php">Citas</a></li>
    <!-- Agrega más elementos del menú si es necesario -->
  </ul>
</div>
</body>
</html>